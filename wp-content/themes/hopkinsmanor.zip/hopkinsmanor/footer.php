</div><!--#stickyfooterinner-->
</div><!--#stickyfooterouter-->

<div id="footer">

	<p><span>Hopkins Manor, Ltd.</span> 610 Smithfield Road, North Providence, RI 02904</p>
	<p class="phone">Call us at (401)353-6300</p>

</div>


<?php wp_footer(); ?>

<!-- asynchronous google analytics change the UA-XXXXX-X to be your site's ID -->
<script>
 var _gaq = [['_setAccount', 'UA-XXXXX-X'], ['_trackPageview']];
 (function(d, t) {
  var g = d.createElement(t),
      s = d.getElementsByTagName(t)[0];
  g.async = true;
  g.src = '//www.google-analytics.com/ga.js';
  s.parentNode.insertBefore(g, s);
 })(document, 'script');
</script>
		
</body>
</html>
